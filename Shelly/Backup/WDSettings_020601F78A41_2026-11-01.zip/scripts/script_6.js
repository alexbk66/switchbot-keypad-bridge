let s = atob("AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8=");
console.log("Length: " + (s ? s.length : "undefined"));
console.log("Hex: " + (s ? btoh(s) : "undefined"));

// LOQED Bridge -> Shelly Wall Display Boolean toggle (one lock per script).
// When configured, verifies on startup that LOQED has registered the exact
// state-reached callback URL before entering webhook-confirmation mode.
// No webhook is created or deleted. No lock command runs on startup.
// IMPORTANT: LOQED bridge AUTHENTICATION key is different from the local
// command-URL secret. Enter it separately; do not share it in logs.


let LOCK_COMPONENT = "boolean:202";  // Verify via Shelly.GetComponents.
let BRIDGE_IP = "192.168.68.87";                // Garage. Front Door: 192.168.68.117.
let SHELLY_IP = "192.168.68.118";

let URL_NIGHT_LOCK = "http://192.168.68.87/state?command=NIGHT_LOCK&local_key_id=4&secret=Gm1BY3ZIzO85xE7lGxNolyktwbBspluDu9DfD3%2F0iso%3D";
let URL_DAY_LOCK = "http://192.168.68.87/state?command=DAY_LOCK&local_key_id=4&secret=Gm1BY3ZIzO85xE7lGxNolyktwbBspluDu9DfD3%2F0iso%3D";
let URL_STATUS = "http://192.168.68.87/status";

// OPTIONAL: Set a long, random token and configure a LOQED Bridge
// state-reached webhook to:
// http://192.168.68.118/script/<script-id>/loqed-state?token=<your-token>
// Only state-reached callbacks are accepted. No webhook is exposed until
// this value is changed from the placeholder.
let WEBHOOK_TOKEN = ""; // "2BwolqIBRdx3Uz6DzPhHl57Rz"
let BRIDGE_AUTH_KEY_B64 = "EqSkwvbAYAsMllVJM6arktkghTv0nCmCSfCzXsVKRdU=";

// Optional on-panel diagnostics; create a separate Text virtual component.
// Use a different ID for each script. Empty string disables on-panel output.
let DEBUG_COMPONENT = "";  // Garage Debug; Front Door can use text:203.

let debugText = DEBUG_COMPONENT ? Virtual.getHandle(DEBUG_COMPONENT) : null;
let debugPrevious = "";
let debugLatest = "";

// Keep the console log and display the last two distinct diagnostic messages.
// Never include command URLs, tokens or bridge authentication material here.
function log(message) {
  console.log(message);
  if (!debugText) return;
  let line = message.indexOf("LOQED: ") === 0 ? message.slice(7) : message;
  if (line === debugLatest) return;
  debugPrevious = debugLatest;
  debugLatest = line;
  let value = debugPrevious ? debugPrevious + "\n" + debugLatest : debugLatest;
  // The Text component in setup below is configured with max_len=255.
  if (value.length > 240) value = value.slice(value.length - 240);
  debugText.setValue(value);
}

let lock = Virtual.getHandle(LOCK_COMPONENT);
let knownState = null;
let updatingFromDevice = null;
let commandPending = false;
let pendingTarget = null;
let webhookEnabled = false; // Only TRUE after signed GET /webhooks verifies registration.
let timeoutSerial = 0;
let webhookEndpoint = null;

function isConfigured(url) {
  return typeof url === "string" &&
    (url.indexOf("http://") === 0 || url.indexOf("https://") === 0);
}
function stateFromLoqed(value) {
  if (typeof value !== "string") return null;
  let s = value.toUpperCase();
  if (s === "NIGHT_LOCK") return true;
  if (s === "DAY_LOCK" || s === "OPEN") return false;
  return null;
}
function setFromLock(value) {
  knownState = value;
  if (!lock || lock.getValue() === value) return;
  updatingFromDevice = value;
  lock.setValue(value);
}

// Decode the Bridge authentication key directly to hexadecimal bytes.
// Avoid relying on atob() for a binary key (which may contain NUL bytes).
// This uses standard Base64, as returned by LOQED's "AUTH KEY (BASE64)" copy button.
function bridgeKeyHex(encoded) {
  let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let hex = "0123456789abcdef";
  if (typeof encoded !== "string") return null;
  let data = "";
  for (let i = 0; i < encoded.length; i++) {
    let ch = encoded[i];
    if (ch === " " || ch === "\n" || ch === "\r" || ch === "\t") continue;
    data += ch;
  }
  if (!data.length || data.length % 4 !== 0) return null;
  let out = "";
  for (let i = 0; i < data.length; i += 4) {
    let a = alphabet.indexOf(data[i]);
    let b = alphabet.indexOf(data[i + 1]);
    let pad2 = data[i + 2] === "=";
    let pad3 = data[i + 3] === "=";
    let c = pad2 ? 0 : alphabet.indexOf(data[i + 2]);
    let d = pad3 ? 0 : alphabet.indexOf(data[i + 3]);
    if (a < 0 || b < 0 || c < 0 || d < 0) return null;
    if ((pad2 && !pad3) || ((pad2 || pad3) && i + 4 !== data.length)) return null;
    if ((pad2 && (b & 15) !== 0) || (pad3 && !pad2 && (c & 3) !== 0)) return null;
    let x = (a << 2) | (b >> 4);
    out += hex[(x >> 4) & 15] + hex[x & 15];
    if (!pad2) {
      x = ((b & 15) << 4) | (c >> 2);
      out += hex[(x >> 4) & 15] + hex[x & 15];
    }
    if (!pad3) {
      x = ((c & 3) << 6) | d;
      out += hex[(x >> 4) & 15] + hex[x & 15];
    }
  }
  return out;
}

// LOQED GET /webhooks signature: SHA256(8-byte BE Unix timestamp ||
//                                   base64-decoded Bridge authentication key).
// The short SHA-256 routine below accepts a hexadecimal-encoded byte stream;
// Shelly scripting does not document a SHA-256 helper.
function u64beHex(n) {
  let digits = "0123456789abcdef";
  let result = "";
  for (let i = 0; i < 8; i++) {
    let b = n % 256;
    result = digits[(b >> 4) & 15] + digits[b & 15] + result;
    n = Math.floor(n / 256);
  }
  return result;
}
function sha256HexBytes(hex) {
  let digits = "0123456789abcdef";
  let k = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  ];
  let h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
           0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  let bytes = [];
  for (let i = 0; i < hex.length; i += 2) {
    let n = digits.indexOf(hex.slice(i,i+1)) * 16 + digits.indexOf(hex.slice(i+1,i+2));
    bytes.push(n);
  }
  let bits = bytes.length * 8;
  bytes.push(128);
  while ((bytes.length % 64) !== 56) bytes.push(0);
  for (let i = 0; i < 4; i++) bytes.push(0); // Length fits in 32 bits.
  for (let i = 3; i >= 0; i--) bytes.push((bits >>> (i * 8)) & 255);

  for (let off = 0; off < bytes.length; off += 64) {
    let w = [];
    for (let i = 0; i < 16; i++) {
      let p = off + i*4;
      w[i] = ((bytes[p] << 24) | (bytes[p+1] << 16) |
              (bytes[p+2] << 8) | bytes[p+3]);
    }
    for (let i = 16; i < 64; i++) {
      let x = w[i-15], y = w[i-2];
      let s0 = ((x >>> 7)|(x << 25)) ^ ((x >>> 18)|(x << 14)) ^ (x >>> 3);
      let s1 = ((y >>> 17)|(y << 15)) ^ ((y >>> 19)|(y << 13)) ^ (y >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) | 0;
    }
    let a=h[0], b=h[1], c=h[2], d=h[3], e=h[4], f=h[5], g=h[6], z=h[7];
    for (let i = 0; i < 64; i++) {
      let s1 = ((e >>> 6)|(e << 26)) ^ ((e >>> 11)|(e << 21)) ^ ((e >>> 25)|(e << 7));
      let ch = (e & f) ^ (~e & g);
      let t1 = (z + s1 + ch + k[i] + w[i]) | 0;
      let s0 = ((a >>> 2)|(a << 30)) ^ ((a >>> 13)|(a << 19)) ^ ((a >>> 22)|(a << 10));
      let maj = (a & b) ^ (a & c) ^ (b & c);
      let t2 = (s0 + maj) | 0;
      z=g; g=f; f=e; e=(d+t1)|0; d=c; c=b; b=a; a=(t1+t2)|0;
    }
    h[0]=(h[0]+a)|0; h[1]=(h[1]+b)|0; h[2]=(h[2]+c)|0; h[3]=(h[3]+d)|0;
    h[4]=(h[4]+e)|0; h[5]=(h[5]+f)|0; h[6]=(h[6]+g)|0; h[7]=(h[7]+z)|0;
  }
  let out = "";
  for (let i = 0; i < 8; i++) {
    for (let s = 28; s >= 0; s -= 4) out += digits[(h[i] >>> s) & 15];
  }
  return out;
}

function checkWebhookRegistration() {
  // A configured endpoint is not proof the Bridge has an outgoing registration.
  webhookEnabled = false;
  if (webhookEndpoint === null ||
      BRIDGE_AUTH_KEY_B64.indexOf("PASTE_") === 0 ||
      WEBHOOK_TOKEN.indexOf("PASTE_") === 0) {
    log("LOQED: Webhook registration unverified (missing bridge key/token); using ACK mode");
    return;
  }
  let keyHex = bridgeKeyHex(BRIDGE_AUTH_KEY_B64);
  if (keyHex === null) {
    log("LOQED: Bridge key Base64 validation failed (length=" +
        BRIDGE_AUTH_KEY_B64.length + "); using ACK mode");
    return;
  }
  log("LOQED: Bridge key decoded (" + (keyHex.length / 2) + " bytes)");
  let timestamp = Math.floor(Date.now() / 1000);
  if (timestamp < 1700000000) {
    log("LOQED: System clock not set; cannot verify registration; using ACK mode");
    return;
  }
  let digest = sha256HexBytes(u64beHex(timestamp) + keyHex);
  let expected = "http://" + SHELLY_IP + webhookEndpoint + "?token=" + WEBHOOK_TOKEN;
  Shelly.call("HTTP.Request", {
    method: "GET",
    url: "http://" + BRIDGE_IP + "/webhooks",
    timeout: 10,
    headers: {"TIMESTAMP": String(timestamp), "HASH": digest}
  }, function(result, ec, msg) {
    if (ec !== 0 || !result || result.code !== 200) {
      log("LOQED: Cannot verify Bridge webhooks (ec=" + ec + ", http=" +
                  (result ? result.code : "none") + "); using ACK mode");
      return;
    }
    let hooks;
    try { hooks = JSON.parse(result.body); }
    catch (e) { log("LOQED: Invalid webhook list; using ACK mode"); return; }
    // GET /webhooks returns a JSON array (LOQED local Bridge API).
    if (!hooks || typeof hooks.length !== "number") {
      log("LOQED: Unexpected webhook list format; using ACK mode");
      return;
    }
    for (let i = 0; i < hooks.length; i++) {
      let wh = hooks[i];
      if (wh.url === expected &&
          Number(wh.trigger_state_changed_open) === 1 &&
          Number(wh.trigger_state_changed_latch) === 1 &&
          Number(wh.trigger_state_changed_night_lock) === 1 &&
          Number(wh.trigger_state_changed_unknown) === 1) {
        webhookEnabled = true;
        log("LOQED: Outgoing webhook VERIFIED on Bridge (id=" + wh.id + ")");
        return;
      }
    }
    log("LOQED: Outgoing webhook MISSING or incomplete on Bridge; using ACK mode");
  });
}

function syncAtStart() {
  if (!isConfigured(URL_STATUS)) {
    log("LOQED: Local STATUS URL missing; toggle disabled");
    return;
  }
  Shelly.call("HTTP.GET", {url: URL_STATUS, timeout: 10}, function(result, ec, msg) {
    if (ec !== 0 || !result || result.code !== 200) {
      log("LOQED: Initial status unavailable (" + ec + ")");
      return;
    }
    let obj;
    try { obj = JSON.parse(result.body); }
    catch (e) { log("LOQED: Invalid status JSON"); return; }
    if (obj.lock_online === 0 || obj.lock_online === false) {
      log("LOQED: Lock offline; toggle disabled");
      return;
    }
    let state = stateFromLoqed(obj.bolt_state);
    if (state === null) {
      log("LOQED: Initial lock state unknown; toggle disabled");
      return;
    }
    setFromLock(state);
    log("LOQED: Initial state " + (state ? "Locked" : "Unlocked"));
  });
}

function onLoqedState(req, res) {
  console.log("LOQED RAW REQUEST: " + JSON.stringify({
  method: req.method,
  query: req.query,
  headers: req.headers,
  body: req.body
}));

    log("LOQED: Incoming webhook: method=" + req.method +
      ", token=" +
      (req.query === "token=" + WEBHOOK_TOKEN ? "OK" : "MISMATCH") +
      ", bodyLength=" + (req.body ? req.body.length : 0));
      
  if (req.method !== "POST") {
    res.code = 405; res.body = "POST required"; res.send(); return;
  }
  
  let expected = "token=" + WEBHOOK_TOKEN;
console.log("LOQED: Query diagnostic: type=" + typeof req.query +
  ", receivedLen=" + (req.query ? req.query.length : 0) +
  ", expectedLen=" + expected.length +
  ", startsWithToken=" + (req.query && req.query.indexOf("token=") === 0) +
  ", matches=" + (req.query === expected));
  
  if (req.query !== "token=" + WEBHOOK_TOKEN) {
    res.code = 403; res.body = "Forbidden"; res.send(); return;
  }
  let obj;
  try { obj = JSON.parse(req.body); }
  catch (e) { res.code = 400; res.body = "Bad JSON"; res.send(); return; }
  // Accept reached-state callbacks only, not go-to-state or other events.
  if (typeof obj.event_type !== "string" ||
      obj.event_type.indexOf("STATE_CHANGED_") !== 0) {
    res.code = 200; res.body = "Ignored"; res.send(); return;
  }
  let state = stateFromLoqed(obj.requested_state);
  commandPending = false;
  timeoutSerial++;
  if (state === null) {
    knownState = null;
    log("LOQED: Reported state unknown; toggle disabled");
  } else {
    setFromLock(state);
    log("LOQED: State confirmed " + (state ? "Locked" : "Unlocked"));
  }
  res.code = 200; res.body = "OK"; res.send();
}

function onToggleChange(ev) {
  if (updatingFromDevice !== null) {
    let internal = ev.value === updatingFromDevice;
    updatingFromDevice = null;
    if (internal) return;
  }
  if (typeof ev.value !== "boolean") return;
  let requested = ev.value;
  if (knownState === null) {
    log("LOQED: Refusing command; no verified initial state yet");
    updatingFromDevice = !requested;
    lock.setValue(!requested);
    return;
  }
  if (commandPending) {
    log("LOQED: Previous command pending; ignoring extra toggle");
    updatingFromDevice = pendingTarget;
    lock.setValue(pendingTarget);
    return;
  }
  if (requested === knownState) return;
  let url = requested ? URL_NIGHT_LOCK : URL_DAY_LOCK;
  if (!isConfigured(url)) {
    log("LOQED: Missing local command URL; reverting display");
    updatingFromDevice = knownState;
    lock.setValue(knownState);
    return;
  }
  commandPending = true;
  pendingTarget = requested;
  timeoutSerial++;
  let serial = timeoutSerial;
  log("LOQED: Request " + (requested ? "LOCK" : "UNLOCK"));
  Shelly.call("HTTP.GET", {url: url, timeout: 10}, function(result, ec, msg) {
    if (webhookEnabled && !commandPending && knownState === requested) return;
    if (ec !== 0 || !result || result.code !== 200) {
      commandPending = false;
      log("LOQED: HTTP command error ec=" + ec + ", http=" +
                  (result ? result.code : "none") + "; outcome uncertain");
      if (knownState !== null && knownState !== requested) {
        updatingFromDevice = knownState;
        lock.setValue(knownState);
      }
      return;
    }
    if (!webhookEnabled) {
      // Unverified registration: use last-request ACK, never claim confirmed.
      knownState = requested;
      commandPending = false;
      log("LOQED: Bridge ACK; displayed state ASSUMED (no verified webhook)");
    } else {
      log("LOQED: Bridge ACK; awaiting physical-state confirmation");
      Timer.set(20000, false, function() {
        if (!commandPending || timeoutSerial !== serial) return;
        commandPending = false;
        knownState = null;
        log("LOQED: No state callback in 20s; state UNKNOWN");
      });
    }
  });
}

if (DEBUG_COMPONENT && !debugText) {
  console.log("LOQED: Debug component " + DEBUG_COMPONENT + " missing; console only");
}

if (!lock) {
  log("LOQED: Missing virtual component " + LOCK_COMPONENT);
} else {
  lock.on("change", onToggleChange);
  if (WEBHOOK_TOKEN.indexOf("PASTE_") !== 0 && WEBHOOK_TOKEN.length >= 16 &&
      typeof HTTPServer !== "undefined") {
    webhookEndpoint = HTTPServer.registerEndpoint("loqed-state", onLoqedState);
    log("LOQED: Local endpoint ready: " + webhookEndpoint);
    checkWebhookRegistration();
  } else {
    log("LOQED: Local webhook endpoint not configured; using ACK mode");
  }
  syncAtStart();
}
// LOQED local Bridge -> Shelly Wall Display X1i (Garage + Front Door).
// One script, two independent Boolean controllers; no HomeSeer/HA/Cloud required.
// ACK mode only: the displayed value is ASSUMED after a successful HTTP command.
// Reads each lock's actual state once at script startup; does not poll.
// No webhook endpoints/registration, no on-panel debug component.
// SECURITY: Command URLs contain LOQED credentials; do not publish this script.
// SAFETY: Stop the old Garage and Front Door scripts before starting this one.

let LOCKS = [
  {
    name: "Garage",
    component: "boolean:202",
    nightLockUrl: "http://192.168.68.87/state?command=NIGHT_LOCK&local_key_id=4&secret=Gm1BY3ZIzO85xE7lGxNolyktwbBspluDu9DfD3%2F0iso%3D",
    dayLockUrl: "http://192.168.68.87/state?command=DAY_LOCK&local_key_id=4&secret=Gm1BY3ZIzO85xE7lGxNolyktwbBspluDu9DfD3%2F0iso%3D",
    statusUrl: "http://192.168.68.87/status"
  },
  {
    name: "Front Door",
    component: "boolean:203",
    nightLockUrl: "http://192.168.68.117/state?command=NIGHT_LOCK&local_key_id=5&secret=KhGpLPJP%2BwolqIBRdx3Uz6DzPhHl57Rz%2FGt0OXAIiW8%3D",
    dayLockUrl: "http://192.168.68.117/state?command=DAY_LOCK&local_key_id=5&secret=KhGpLPJP%2BwolqIBRdx3Uz6DzPhHl57Rz%2FGt0OXAIiW8%3D",
    statusUrl: "http://192.168.68.117/status"
  }
];

function log(name, message) {
  console.log("LOQED [" + name + "]: " + message);
}

function isConfigured(url) {
  return typeof url === "string" &&
         (url.indexOf("http://") === 0 || url.indexOf("https://") === 0);
}

function stateFromLoqed(value) {
  if (typeof value !== "string") return null;
  let state = value.toUpperCase();
  if (state === "NIGHT_LOCK") return true;
  if (state === "DAY_LOCK" || state === "OPEN") return false;
  return null;
}

function initLock(cfg) {
  let lock = Virtual.getHandle(cfg.component);
  if (!lock) {
    log(cfg.name, "Missing component " + cfg.component);
    return;
  }

  // These variables belong only to this lock, not the other controller.
  let knownState = null;
  let updatingFromDevice = null;
  let commandPending = false;
  let pendingTarget = null;

  function setDisplay(value) {
    if (lock.getValue() === value) return;
    updatingFromDevice = value;
    lock.setValue(value);
  }

  function setFromLock(value) {
    knownState = value;
    setDisplay(value);
  }

  function onToggleChange(ev) {
    // Shelly also generates change events for our own setValue() calls.
    if (updatingFromDevice !== null) {
      let internal = ev.value === updatingFromDevice;
      updatingFromDevice = null;
      if (internal) return;
    }
    if (typeof ev.value !== "boolean") return;
    let requested = ev.value;

    if (knownState === null) {
      log(cfg.name, "Refusing command: no verified initial state");
      setDisplay(!requested);
      return;
    }
    if (commandPending) {
      log(cfg.name, "Command pending; ignoring extra toggle");
      setDisplay(pendingTarget);
      return;
    }
    if (requested === knownState) return;

    let url = requested ? cfg.nightLockUrl : cfg.dayLockUrl;
    if (!isConfigured(url)) {
      log(cfg.name, "Missing command URL; reverting display");
      setDisplay(knownState);
      return;
    }

    commandPending = true;
    pendingTarget = requested;
    log(cfg.name, "Request " + (requested ? "LOCK" : "UNLOCK"));
    Shelly.call("HTTP.GET", {url: url, timeout: 10}, function(result, ec, msg) {
      commandPending = false;
      if (ec !== 0 || !result || result.code !== 200) {
        log(cfg.name, "HTTP command error: ec=" + ec +
            ", http=" + (result ? result.code : "none") +
            "; physical outcome UNKNOWN");
        // Same behaviour as the original script: restore previous display.
        // It may be stale if the bridge acted despite the HTTP failure.
        setDisplay(knownState);
        return;
      }
      // HTTP 200 confirms Bridge acceptance, NOT physical lock movement.
      knownState = requested;
      log(cfg.name, "Bridge ACK; displayed state ASSUMED");
    });
  }

  function syncAtStart() {
    if (!isConfigured(cfg.statusUrl)) {
      log(cfg.name, "Status URL missing; toggle disabled");
      return;
    }
    Shelly.call("HTTP.GET", {url: cfg.statusUrl, timeout: 10},
      function(result, ec, msg) {
        if (ec !== 0 || !result || result.code !== 200) {
          log(cfg.name, "Initial status unavailable: ec=" + ec);
          return;
        }
        let obj;
        try { obj = JSON.parse(result.body); }
        catch (e) {
          log(cfg.name, "Invalid initial status JSON");
          return;
        }
        if (obj.lock_online === 0 || obj.lock_online === false) {
          log(cfg.name, "Lock offline; toggle disabled");
          return;
        }
        let state = stateFromLoqed(obj.bolt_state);
        if (state === null) {
          log(cfg.name, "Initial state unknown; toggle disabled");
          return;
        }
        setFromLock(state);
        log(cfg.name, "Initial state " + (state ? "Locked" : "Unlocked"));
      });
  }

  lock.on("change", onToggleChange);
  syncAtStart();
}

for (let i = 0; i < LOCKS.length; i++) {
  initLock(LOCKS[i]);
}

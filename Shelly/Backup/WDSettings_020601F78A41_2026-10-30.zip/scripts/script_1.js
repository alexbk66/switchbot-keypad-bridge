let hub = Matter.getHandle(1);
print(JSON.stringify(hub.getComponents()));

let presence = Virtual.getHandle("boolean:200");

if (!hub || !presence) {
    print("ERROR: Matter hub or virtual Boolean not found");
} else {
    let lastValue = null;

    function updatePresence() {
        let status = hub.getStatus();
        if (!status || !status.online)
            return;

        let sensor = status["occupancy:1"];
        if (!sensor || typeof sensor.value !== "boolean")
            return;

        if (sensor.value === lastValue)
            return;

        lastValue = sensor.value;
        presence.setValue(lastValue);

        print("Presence: " + (lastValue ? "Occupied" : "Vacant"));
        
        Shelly.call("Switch.Set", {id: 0, on: lastValue},
        
        function(result, error_code, error_message) {
            if (error_code !== 0)
                print("Switch.Set failed: " + error_message);
        });
    }

    // Set initial state
    updatePresence();

    // Subscribe to Matter changes
    hub.on("change", updatePresence);
}
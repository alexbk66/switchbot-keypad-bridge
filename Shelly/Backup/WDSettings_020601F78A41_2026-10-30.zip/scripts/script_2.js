// Shelly Wall Display X1i — SwitchBot Keypad Vision Pro compact monitor.
// Replaces the OLD keypad monitor script (do NOT run both).
// Does not control the keypad, lock, or LOQED.
//
// Source: ESP32 status at 192.168.68.56:8080/api/status
// Existing Shelly virtual components:
//   text:200    last action (written by ESP32)
//   text:201    combined two-line display (written here)
//   number:200  keypad battery
//   boolean:201 tamper alarm
//
// Put text:201 on a double-height dashboard tile with Label view.
// Expected content: "FP2-1\nOK 100%"

let STATUS_URL = "http://192.168.68.56:8080/api/status";
let ACTION_ID = 200;
let DISPLAY_ID = 201;
let BATTERY_ID = 200;
let TAMPER_ID = 201;
let POLL_MS = 30000;
let OFFLINE_AFTER = 3;

let busy = false;
let failures = 0;
let action = "--";
let health = "WAIT";
let battery = null;
let staleBattery = false;
let lastBatterySet = null;
let lastTamperSet = null;
let lastWritten = null;
let requestedText = null;
let textWriteBusy = false;

// Also understands the old ESPHome action format (fingerprint #2 (1)).
function compactAction(raw) {
  if (typeof raw !== "string" || raw.length === 0) return "--";
  let s = raw;
  if (s.charAt(0) === '"' && s.charAt(s.length - 1) === '"')
    s = s.substring(1, s.length - 1);
  let open = s.lastIndexOf("(");
  let close = s.lastIndexOf(")");
  let seq = open >= 0 && close > open ? s.substring(open + 1, close) : "";
  let lower = s.toLowerCase();
  if (lower.indexOf("lock") === 0 && lower.indexOf("lockout") !== 0)
    return "L" + seq;
  if (lower.indexOf("doorbell") === 0) return "B" + seq;

  let code = "";
  if (lower.indexOf("fingerprint") === 0) code = "FP";
  else if (lower.indexOf("face") === 0) code = "F";
  else if (lower.indexOf("palm") === 0) code = "PA";
  else if (lower.indexOf("pin") === 0) code = "P";
  else if (lower.indexOf("nfc") === 0) code = "N";
  if (code !== "") {
    let start = s.indexOf("#");
    let end = start >= 0 ? s.indexOf(" ", start) : -1;
    let index = start >= 0 ? s.substring(start + 1, end < 0 ? s.length : end) : "";
    return code + index + (seq !== "" ? "-" + seq : "");
  }
  return s;
}

function getAction() {
  let st = Shelly.getComponentStatus("text", ACTION_ID);
  return compactAction(st && st.value);
}

// Serialize Text.Set calls: the latest action/health must win.
function flushDisplay() {
  if (textWriteBusy || requestedText === null || requestedText === lastWritten) return;
  let value = requestedText;
  textWriteBusy = true;
  Shelly.call("Text.Set", {id: DISPLAY_ID, value: value}, function (_r, ec, msg) {
    textWriteBusy = false;
    if (ec === 0) {
      lastWritten = value;
      console.log("Keypad: " + value.replace("\n", " / "));
    } else console.log("Keypad Text.Set failed: " + ec + " " + msg);
    if (requestedText !== value) flushDisplay();
  });
}

function render() {
  let line2 = health;
  // Keep second line short; avoid the panel wrapping "Connected".
  if ((health === "OK" || health === "SEEN") && battery !== null) {
    line2 = (health === "SEEN" ? "SE" : "OK") + " " + battery + (staleBattery ? "*" : "") + "%";
  }
  requestedText = action + "\n" + line2;
  flushDisplay();
}

function setBattery(value) {
  if (typeof value !== "number" || value < 0 || value > 100) return;
  battery = Math.round(value);
  if (battery === lastBatterySet) return;
  // ESPHome also writes number:200. Avoid unnecessary duplicate updates.
  let old = Shelly.getComponentStatus("number", BATTERY_ID);
  if (old && old.value === battery) {
    lastBatterySet = battery;
    return;
  }
  Shelly.call("Number.Set", {id: BATTERY_ID, value: battery}, function (_r, ec, msg) {
    if (ec === 0) lastBatterySet = battery;
    else console.log("Keypad Number.Set failed: " + ec + " " + msg);
  });
}

function setTamper(value) {
  if (typeof value !== "boolean" || value === lastTamperSet) return;
  let old = Shelly.getComponentStatus("boolean", TAMPER_ID);
  if (old && old.value === value) {
    lastTamperSet = value;
    return;
  }
  Shelly.call("Boolean.Set", {id: TAMPER_ID, value: value}, function (_r, ec, msg) {
    if (ec === 0) lastTamperSet = value;
    else console.log("Keypad Boolean.Set failed: " + ec + " " + msg);
  });
}

function poll() {
  if (busy) return;
  busy = true;
  Shelly.call("HTTP.GET", {url: STATUS_URL, timeout: 4}, function (result, ec, msg) {
    busy = false;
    let data = null;
    if (ec === 0 && result && result.code === 200 && typeof result.body === "string") {
      try { data = JSON.parse(result.body); } catch (e) { console.log("Invalid keypad JSON"); }
    }
    if (!data || !data.keypad || typeof data.keypad.paired !== "boolean") {
      failures++;
      if (failures === 1) console.log("Keypad HTTP error: " + ec + " " + msg);
      if (failures >= OFFLINE_AFTER) {
        health = "ESP OFF";
        render();
      }
      return;
    }

    failures = 0;
    let k = data.keypad;
    setBattery(k.battery);
    setTamper(k.tamper_alarm);
    staleBattery = typeof k.battery_age_s === "number" && k.battery_age_s > 300;

    // Important alarms take precedence over the battery display.
    if (k.duress_alarm === true) health = "DURESS";
    else if (k.tamper_alarm === true) health = "TAMPER";
    else if (k.lockout_alarm === true) health = "LOCKOUT";
    else if (!k.paired) health = "UNPAIRED";
    else if (k.online === null || typeof k.online !== "boolean") health = "UNKNOWN";
    else if (!k.online) health = "OFFLINE";
    else if (k.ble_connected) health = "OK";
    else health = "SEEN";

    render();
  });
}

if (Shelly.getComponentStatus("text", ACTION_ID) === null ||
    Shelly.getComponentStatus("text", DISPLAY_ID) === null) {
  console.log("WARNING: missing text:200 or text:201");
}
if (Shelly.getComponentStatus("number", BATTERY_ID) === null)
  console.log("WARNING: missing number:200");
if (Shelly.getComponentStatus("boolean", TAMPER_ID) === null)
  console.log("WARNING: missing boolean:201");

action = getAction();

// Update immediately for each new action; HTTP polling remains every 30 s.
Shelly.addStatusHandler(function (status) {
  if (status.component === "text:200") {
    if (status.delta && typeof status.delta.value === "string")
      action = compactAction(status.delta.value);
    else action = getAction();
    render();
  }
});

render();
poll();
Timer.set(POLL_MS, true, poll);

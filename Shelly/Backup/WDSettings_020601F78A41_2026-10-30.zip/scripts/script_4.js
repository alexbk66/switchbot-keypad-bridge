// SwitchBot Keypad Vision Pro -> LOQED, entirely within Shelly Wall Display.
// Requires the existing, WORKING LOQED Boolean-toggle script to be running.
// The keypad/ESP32 writes short action codes to text:200 (FP2-5, F1-6, L7).
// This script maps those actions to the existing boolean:202 toggle.
// The existing LOQED script does the actual local Bridge HTTP request.
// No additional API secrets, ESPHome changes or virtual components needed.
//
// SECURITY: anyone with permission to write text:200 can request an unlock.
// Protect Shelly RPC access on the local network.

let KEYPAD_ACTION_COMPONENT = "text:200";
let LOQED_TOGGLE_COMPONENT = "boolean:202";

let action = Virtual.getHandle(KEYPAD_ACTION_COMPONENT);
let loqed = Virtual.getHandle(LOQED_TOGGLE_COMPONENT);

function onlyDigits(s) {
  if (s.length === 0) return false;
  for (let i = 0; i < s.length; i++) {
    if ("0123456789".indexOf(s.substr(i, 1)) < 0) return false;
  }
  return true;
}

// Return true=lock, false=unlock, null=ignore.
// Accept only the short event format emitted by our current ESPHome YAML.
function targetFromAction(s) {
  if (typeof s !== "string") return null;

  // Keypad's Lock button: L<sequence>
  if (s.substr(0, 1) === "L" && onlyDigits(s.substr(1))) return true;

  // Accepted authenticated keypad unlocks:
  // F<slot>-<sequence>, FP<slot>-<sequence>, P<slot>-<sequence>,
  // PA<slot>-<sequence>, N<slot>-<sequence>.
  // Ignore U (unknown method) and B (doorbell).
  let dash = s.indexOf("-");
  if (dash < 2 || !onlyDigits(s.substr(dash + 1))) return null;
  let head = s.substr(0, dash);
  let prefix = head.substr(0, 2);
  if (prefix !== "FP" && prefix !== "PA") prefix = head.substr(0, 1);
  if (prefix !== "FP" && prefix !== "PA" && prefix !== "F" &&
      prefix !== "P" && prefix !== "N") return null;
  if (!onlyDigits(head.substr(prefix.length))) return null;
  return false;
}

if (!action || !loqed) {
  console.log("SB->LOQED: Missing component(s): " +
              KEYPAD_ACTION_COMPONENT + " or " + LOQED_TOGGLE_COMPONENT);
} else {
  // Do NOT interpret the saved/initial action at startup as a new command.
  let previousAction = action.getValue();
  action.on("change", function(ev) {
    let s = ev.value;
    if (s === previousAction) return;
    previousAction = s;

    let target = targetFromAction(s);
    if (target === null) {
      console.log("SB->LOQED: Ignored " + s);
      return;
    }

    // No need to send the same request again if the toggle already shows it.
    // The existing LOQED script handles its own pending/unknown state checks.
    if (loqed.getValue() === target) {
      console.log("SB->LOQED: Already " + (target ? "locked" : "unlocked"));
      return;
    }
    console.log("SB->LOQED: " + s + " -> " + (target ? "LOCK" : "UNLOCK"));
    loqed.setValue(target);
  });
  console.log("SB->LOQED: Listening for keypad actions; initial value ignored");
}
